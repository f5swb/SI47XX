var group__group01_structsi473x__powerup_8arg =
[
    [ "FUNC", "group__group01.html#a1e49c8ad07b69571bfcafaf18ac9fa5b", null ],
    [ "XOSCEN", "group__group01.html#a22c9aef8785be330d7e1faf88bcfd4b1", null ],
    [ "PATCH", "group__group01.html#a63bc9a3997d66d835d9f3ec29451407d", null ],
    [ "GPO2OEN", "group__group01.html#a16e39ff0e3715799964f55ae2059869d", null ],
    [ "CTSIEN", "group__group01.html#a70cc84d478cf749951dcd0abde88b0ce", null ],
    [ "OPMODE", "group__group01.html#adc7ae7360da2a9886f674ed6943a2524", null ]
];