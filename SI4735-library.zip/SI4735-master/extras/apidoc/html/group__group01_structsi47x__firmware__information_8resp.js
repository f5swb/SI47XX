var group__group01_structsi47x__firmware__information_8resp =
[
    [ "STCINT", "group__group01.html#af8f21d801809287d578344911b65697c", null ],
    [ "DUMMY1", "group__group01.html#a3651c40ccc4450f2fc89fa3139dedd5a", null ],
    [ "RDSINT", "group__group01.html#a53d648e7e9d100d590e2f65ec7de079f", null ],
    [ "RSQINT", "group__group01.html#a8acf6c55c97050e7abd06c104012c77a", null ],
    [ "DUMMY2", "group__group01.html#abece94c62273dc7ecfabc565b76dbbe5", null ],
    [ "ERR", "group__group01.html#acd22bad976363fdd1bfbf6759fede482", null ],
    [ "CTS", "group__group01.html#ae16433ffd3adc248f0ce2608a95c3c76", null ],
    [ "PN", "group__group01.html#a7b6166324dc52f374d908e03602b1daf", null ],
    [ "FWMAJOR", "group__group01.html#a67c65213847ea2a824306b665bd2851f", null ],
    [ "FWMINOR", "group__group01.html#ae0c243088677f14fc8dd9c9508e068ff", null ],
    [ "PATCHH", "group__group01.html#a3ab7055a80e6c432a1116bfb27181811", null ],
    [ "PATCHL", "group__group01.html#a07cead1237e34b4696dce647443ad10e", null ],
    [ "CMPMAJOR", "group__group01.html#aab5038bb547e9aa4b543112de6904611", null ],
    [ "CMPMINOR", "group__group01.html#a62c98580b8d5220cf351861ddd86fd07", null ],
    [ "CHIPREV", "group__group01.html#ab9dbe73951d365ea8a945760cec79a5e", null ]
];