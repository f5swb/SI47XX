# Original sketch developed by Plamen Panteleev, LZ1PPL.

All you need to know about the Plamen's hardware and firmware can be found [here.](https://www.lz1ppl.com/en/2021/04/22/si4735-all-mode-reciver/?fbclid=IwAR10n3x89ayj332m2X3x65AAR6bMVARHZ5VdDtkEzusT_qmUE-F6u9_QIaI)





